globalThis._importMeta_={url:import.meta.url,env:process.env};export { z as handler } from './chunks/nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
//# sourceMappingURL=index.mjs.map
